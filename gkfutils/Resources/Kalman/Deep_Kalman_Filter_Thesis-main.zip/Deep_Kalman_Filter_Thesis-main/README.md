# Deep_Kalman_Filter_Thesis
This is a repo of my bachelor's degree thesis project.

Model taken from: https://github.com/kokikwbt/deep-kalman-filter

Data taken from: https://sites.google.com/eng.ucsd.edu/fitrec-project/home?pli=1      (endomondoHR_proper.json)
