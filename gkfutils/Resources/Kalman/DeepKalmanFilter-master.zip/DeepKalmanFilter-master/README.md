# Pytorch Re-Implementation of DeepKalmanFilter
wip

Model structure is based on PlaNet [2] and https://github.com/DanieleGammelli/DeepKalmanFilter.

## Reference
[1] Deep Kalman Filters. Rahul G. Krishnan, Uri Shalit, David Sontag. 


[2] Learning Latent Dynamics for Planning from Pixels. Hafner, Danijar and Lillicrap, Timothy and Fischer, Ian and Villegas, Ruben and Ha, David and Lee, Honglak and Davidson, James.

