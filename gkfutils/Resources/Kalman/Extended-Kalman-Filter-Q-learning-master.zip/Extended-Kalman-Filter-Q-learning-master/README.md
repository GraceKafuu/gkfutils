# Extended-Kalman-Filter-Q-learning
A PyTorch implementation of the Extended Kalman Filter Q-learning algorithm presented in the paper "Deep Robust Kalman Filter" 
